--[[--
HTTP client for the Coppice REST surfaces.

Pairing is unauthenticated and is the only onboarding path. The server returns
an API key for OPDS, catalog, downloads and KOReader progress plus a separate
liseur device token for annotations/read state. Neither secret is created or
stored by this plugin until the user approves the six-digit code.

After pairing:

| Surface                | Credential                              |
| ---------------------- | --------------------------------------- |
| `/opds/v2.0/...`       | Basic user:api_key                      |
| `/api/v2/...`          | Bearer api_key                          |
| `/koreader/{api_key}`  | the API key in the path                  |
| `/v1/...`              | Bearer liseur device token              |
]]

local http = require("socket.http")
local ltn12 = require("ltn12")
local mime = require("mime")
local rapidjson = require("rapidjson")
local socket = require("socket")
local socketutil = require("socketutil")
local logger = require("logger")

-- `socket.http.request` only understands `https://` once LuaSec is loaded.
-- `socketutil` already requires it; doing it here keeps the dependency
-- visible instead of load-order luck.
pcall(require, "ssl.https")

local Url = require("coppice_url")

local Api = {}
Api.__index = Api

local MAX_REDIRECTS = 4
local MAX_JSON_BYTES = 8 * 1024 * 1024

--- JSON `null` decodes to a lightuserdata that is *truthy* in Lua; left alone
--- it leaks into settings files and every `if value then` test.
local function scrubNulls(value)
    if value == rapidjson.null then return nil end
    if type(value) == "table" then
        for key, item in pairs(value) do
            value[key] = scrubNulls(item)
        end
    end
    return value
end

local function decode(parts)
    local raw = table.concat(parts or {})
    if raw == "" then return {} end
    local ok, decoded = pcall(rapidjson.decode, raw)
    if not ok or decoded == nil then
        return nil, "invalid_json", raw
    end
    return scrubNulls(decoded) or {}
end

local function basicHeader(username, secret)
    return "Basic " .. mime.b64(tostring(username) .. ":" .. tostring(secret))
end

function Api.new(opts)
    opts = opts or {}
    return setmetatable({
        base = opts.base,
        username = opts.username,
        api_key = opts.api_key,
        device_id = opts.device_id,
        device_name = opts.device_name,
        liseur_secret = opts.liseur_secret,
    }, Api)
end

function Api:isConfigured()
    return self.base ~= nil
        and (self.username or "") ~= ""
        and (self.api_key or "") ~= ""
        and (self.liseur_secret or "") ~= ""
end

--- OPDS uses Basic only as a transport wrapper around the API key.
function Api:opdsAuthHeader()
    if not self.username or self.username == "" then return nil end
    if self.api_key and self.api_key ~= "" then
        return basicHeader(self.username, self.api_key)
    end
    return nil
end

--- The credential `/api/v2` gets: a Bearer API key from pairing.
function Api:apiAuthHeaders()
    if self.api_key and self.api_key ~= "" then
        return { ["Authorization"] = "Bearer " .. self.api_key }
    end
    return {}
end

--- One blocking request.
---
--- Returns `decoded_body, nil, code` on 2xx; `nil, err, code, decoded_error`
--- otherwise, where `err` is the HTTP status line for an HTTP error and a
--- transport string ("timeout", "closed", ...) for a socket failure.
function Api:request(spec)
    local sink_parts = {}
    local headers = {
        ["accept"] = "application/json",
    }
    for key, value in pairs(spec.headers or {}) do
        headers[key] = value
    end

    local request = {
        url = spec.url,
        method = spec.method or "GET",
        sink = socketutil.table_sink(sink_parts),
        headers = headers,
    }

    if spec.json ~= nil then
        local ok, body = pcall(rapidjson.encode, spec.json)
        if not ok or type(body) ~= "string" then
            return nil, "encode_failed"
        end
        request.source = ltn12.source.string(body)
        headers["content-type"] = "application/json"
        headers["content-length"] = tostring(#body)
    end

    socketutil:set_timeout(
        spec.block_timeout or socketutil.LARGE_BLOCK_TIMEOUT,
        spec.total_timeout or socketutil.LARGE_TOTAL_TIMEOUT)
    local request_ok, code, response_headers, status = pcall(function()
        return socket.skip(1, http.request(request))
    end)
    socketutil:reset_timeout()

    if not request_ok then
        logger.warn("Coppice: request failed", code, spec.log_url or spec.url)
        return nil, tostring(code or "network_error")
    end
    if type(code) ~= "number" then
        logger.warn("Coppice: transport error", status or code, spec.log_url or spec.url)
        return nil, tostring(status or code or "network_error")
    end


    local raw_size = 0
    for _, part in ipairs(sink_parts) do raw_size = raw_size + #part end
    if raw_size > MAX_JSON_BYTES then
        return nil, "response_too_large", code
    end

    local body, decode_err = decode(sink_parts)

    if code < 200 or code >= 300 then
        return nil, tostring(status or code), code, body
    end
    if decode_err then
        return nil, decode_err, code
    end
    return body or {}, nil, code
end

-- --------------------------------------------------------------- pairing

--- Starts the unauthenticated five-minute device pairing window.
---
--- The response contains a one-time six-digit code and a poll nonce. Both are
--- kept only in settings while pending; the nonce is never sent anywhere but
--- the matching status URL.
function Api:pairingStart(name)
    local body, err, code = self:request({
        url = Url.api(self.base, "/devices/pair/start"),
        method = "POST",
        json = { kind = "coppice", name = name },
    })
    if not body then return nil, err, code end
    if type(body) ~= "table"
        or type(body.pairing_id) ~= "string" or body.pairing_id == ""
        or type(body.code) ~= "string" or not body.code:match("^%d%d%d%d%d%d$")
        or type(body.nonce) ~= "string" or body.nonce == ""
        or type(body.expires_at) ~= "string" or body.expires_at == ""
    then
        return nil, "invalid_pairing_start", code
    end
    return body, nil, code
end

--- Polls an existing pairing using its nonce. The nonce is included in the
--- query because the server deliberately treats it as a proof of possession.
function Api:pairingStatus(pairing_id, nonce)
    if type(pairing_id) ~= "string" or pairing_id == ""
        or type(nonce) ~= "string" or nonce == ""
    then
        return nil, "invalid_pairing", nil
    end
    local body, err, code = self:request({
        url = Url.api(self.base,
            "/devices/pair/" .. Url.escape(pairing_id) .. "/status",
            { nonce = nonce }),
        log_url = Url.api(self.base,
            "/devices/pair/" .. Url.escape(pairing_id) .. "/status"),
    })
    if not body then return nil, err, code end
    if type(body) ~= "table"
        or type(body.status) ~= "string"
        or not ({ pending = true, approved = true, denied = true, expired = true })[body.status]
    then
        return nil, "invalid_pairing_status", code
    end
    return body, nil, code
end

-- ---------------------------------------------------------------- OPDS 2.0

function Api:opdsGet(url)
    local auth = self:opdsAuthHeader()
    if not auth then return nil, "no_credentials" end
    local body, err, code = self:request({
        url = url,
        headers = { ["Authorization"] = auth },
    })
    if not body then return nil, err, code end
    if type(body) ~= "table" then return nil, "invalid_response", code end
    return body, nil, code
end

function Api:opdsCatalog()
    return self:opdsGet(Url.opds(self.base, "/catalog"))
end

--- Feeds below the root are reached by following the `href`s the server put
--- in the previous feed (that is what OPDS navigation is), so there are no
--- per-feed wrappers here — only the two entry points a caller cannot be
--- handed a link to.

function Api:opdsSearch(query, page, page_size)
    return self:opdsGet(Url.opds(self.base, "/search",
        { query = query, page = page, page_size = page_size }))
end

-- --------------------------------------------------------------- /api/v2

function Api:apiGet(path, params)
    local body, err, code, error_body = self:request({
        url = Url.api(self.base, path, params),
        headers = self:apiAuthHeaders(),
    })
    return body, err, code, error_body
end

--- `GET /api/v2/reading/continue` — the continue-reading dashboard.
function Api:continueReading(limit)
    local body, err, code = self:apiGet("/reading/continue", { limit = limit })
    if not body then return nil, err, code end
    if type(body) ~= "table" or type(body.items) ~= "table" then
        return nil, "invalid_response", code
    end
    return body.items, nil, code
end

-- --------------------------------------------------------------- downloads

--- Streams a URL to `target_path`.
---
--- Writes through `<target>.part` and renames, so an interrupted download
--- never leaves a truncated file that KOReader would then try to open.
function Api:downloadTo(url, target_path, auth_headers)
    if type(url) ~= "string" or url == "" then return nil, "no_url" end
    if type(target_path) ~= "string" or target_path == "" then
        return nil, "no_target"
    end

    local partial = target_path .. ".part"
    local out, io_err = io.open(partial, "wb")
    if not out then return nil, io_err or "cannot_open_target" end

    local function close_out()
        if out then
            pcall(function() out:close() end)
            out = nil
        end
    end

    local headers = {}
    for key, value in pairs(auth_headers or {}) do headers[key] = value end

    local current_url, redirects = url, 0
    local code, response_headers, status
    while true do
        socketutil:set_timeout(
            socketutil.FILE_BLOCK_TIMEOUT, socketutil.FILE_TOTAL_TIMEOUT)
        local request_ok
        request_ok, code, response_headers, status = pcall(function()
            return socket.skip(1, http.request({
                url = current_url,
                method = "GET",
                sink = socketutil.file_sink(out),
                headers = headers,
            }))
        end)
        socketutil:reset_timeout()

        if not request_ok then
            close_out()
            break
        end
        if type(code) == "number" and code >= 300 and code < 400
                and redirects < MAX_REDIRECTS then
            local location = response_headers
                and (response_headers["location"] or response_headers["Location"])
            if not location then break end
            current_url = Url.rebase(self.base, location) or location
            redirects = redirects + 1
            -- `file_sink` closed the handle on the redirect body; start over.
            out = io.open(partial, "wb")
            if not out then
                os.remove(partial)
                return nil, "cannot_reopen_target"
            end
        else
            break
        end
    end

    if type(code) ~= "number" then
        close_out()
        os.remove(partial)
        return nil, tostring(status or code or "network_error")
    end
    if code < 200 or code >= 300 then
        close_out()
        os.remove(partial)
        return nil, tostring(status or code), code
    end

    local ok, rename_err = os.rename(partial, target_path)
    if not ok then
        close_out()
        os.remove(partial)
        return nil, rename_err or "cannot_rename"
    end
    return target_path
end

--- The book file. `/api/v2/media/{id}/file` is used rather than the OPDS
--- acquisition link so the download rides the same credential as the
--- dashboard; both serve the original bytes.
function Api:downloadBook(book_id, target_path)
    return self:downloadTo(
        Url.api(self.base, "/media/" .. Url.escape(book_id) .. "/file"),
        target_path,
        self:apiAuthHeaders())
end

-- ----------------------------------------------------------------- kosync

--- `GET /koreader/{key}/users/auth` -> `{"authorized":"OK"}`.
---
--- Coppice ignores the kosync username and digest entirely (KOReader sends an MD5
--- of the reusable secret, which cannot be checked against a bcrypt hash); the key in
--- the path is the credential.
function Api:kosyncAuth()
    local url = Url.kosyncAuth(self.base, self.api_key)
    if not url then return nil, "no_api_key" end
    local body, err, code = self:request({ url = url })
    if not body then return nil, err, code end
    if type(body) ~= "table" or body.authorized ~= "OK" then
        return nil, "invalid_response", code
    end
    return body, nil, code
end

--- `PUT /koreader/{key}/syncs/progress`.
---
--- `progress` is a *string*: a page number for a paged document, a crengine
--- DOM x-pointer for a reflowable one. `percentage` is `0..=1`. Both fields
--- plus `device` and `device_id` are required by the server DTO
--- (`coppice_koreader::PutProgressInput`).
function Api:kosyncPush(document, progress, percentage)
    local url = Url.kosyncPutProgress(self.base, self.api_key)
    if not url then return nil, "no_api_key" end
    if type(document) ~= "string" or document == "" then
        return nil, "no_document_hash"
    end
    if progress == nil then return nil, "no_progress" end
    if type(percentage) ~= "number" or percentage ~= percentage
            or percentage < 0 or percentage > 1 then
        return nil, "invalid_percentage"
    end
    return self:request({
        url = url,
        method = "PUT",
        json = {
            document = document,
            progress = tostring(progress),
            percentage = percentage,
            device = self.device_name or "KOReader",
            device_id = self.device_id or "koreader",
        },
        block_timeout = 5,
        total_timeout = 15,
    })
end

--- `GET /koreader/{key}/syncs/progress/{document}`.
function Api:kosyncPull(document)
    local url = Url.kosyncGetProgress(self.base, self.api_key, document)
    if not url then return nil, "no_api_key_or_document" end
    local body, err, code = self:request({
        url = url,
        block_timeout = 5,
        total_timeout = 15,
    })
    if not body then return nil, err, code end
    if type(body) ~= "table" or type(body.document) ~= "string" then
        return nil, "invalid_response", code
    end
    return body, nil, code
end

-- ------------------------------------------------------------ liseur-sync

function Api:liseurDescribeToken(secret)
    if type(secret) ~= "string" or secret == "" then
        return nil, "no_secret"
    end
    local body, err, code = self:request({
        url = Url.liseur(self.base, "/token"),
        headers = { ["Authorization"] = "Bearer " .. secret },
    })
    if not body then return nil, err, code end
    if type(body) ~= "table" then return nil, "invalid_response", code end
    return body, nil, code
end


--- `POST /v1/books/{book_id}/resolve` -> the user's `work_id` for that book.
---
--- Positions and annotations are keyed by a user-scoped Work, never by a
--- `media_id`, so this is the mandatory first step of the annotation lane.
---
--- Returns `work_id, response_body` or `nil, message`. The failure message
--- prefers the server's own `error` field, because the two failures a user
--- will actually hit both say something specific: a `409` "identifiers
--- resolve to multiple works" (two library copies claim the same identity)
--- and a `500` on a directory-backed book (the resolver digests the file, and
--- a multi-file audiobook has no single file to digest).
function Api:liseurResolveWork(secret, book_id)
    local body, err, code, error_body = self:request({
        url = Url.liseur(self.base, "/books/" .. Url.escape(book_id) .. "/resolve"),
        method = "POST",
        headers = { ["Authorization"] = "Bearer " .. secret },
        json = {},
    })
    if not body then
        local message = type(error_body) == "table" and error_body.error or err
        return nil, tostring(message or code)
    end
    if type(body) ~= "table" then return nil, "invalid_response", code end
    if type(body.work_id) ~= "string" or body.work_id == "" then
        return nil, "no_work_id", code
    end
    return body.work_id, body
end

--- `POST /v1/annotations` -> a per-item result list.
---
--- The batch is not atomic: each item comes back `applied`, `duplicate`,
--- `conflict` or `invalid`, and a `conflict` carries the server's current copy
--- so the caller can retry from the new revision.
function Api:liseurPushAnnotations(secret, annotations)
    local body, err, code = self:request({
        url = Url.liseur(self.base, "/annotations"),
        method = "POST",
        headers = { ["Authorization"] = "Bearer " .. secret },
        json = { annotations = annotations },
    })
    if not body then return nil, err, code end
    if type(body) ~= "table" or type(body.results) ~= "table" then
        return nil, "invalid_response", code
    end
    return body, nil, code
end

--- `GET /v1/works/{work_id}/annotations` -> the live set (no tombstones).
function Api:liseurWorkAnnotations(secret, work_id)
    local body, err, code = self:request({
        url = Url.liseur(self.base,
            "/works/" .. Url.escape(work_id) .. "/annotations"),
        headers = { ["Authorization"] = "Bearer " .. secret },
    })
    if not body then return nil, err, code end
    if type(body) ~= "table" or type(body.annotations) ~= "table" then
        return nil, "invalid_response", code
    end
    return body, nil, code
end

return Api
