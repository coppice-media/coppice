--[[--
Coppice — a first-party KOReader plugin for a self-hosted Coppice server.

What it does, and which Coppice surface each part uses:

| Feature                      | Surface                                        |
| ---------------------------- | ---------------------------------------------- |
| Continue reading (dashboard) | `GET /api/v2/reading/continue`                 |
| Browse libraries/series/books| `GET /opds/v2.0/...` (JSON)                    |
| Download a book              | `GET /api/v2/media/{id}/file`                  |
| Progress, automatic          | KOReader's built-in `kosync`, pointed at Coppice |
| Progress, on demand          | `/koreader/{api_key}/syncs/progress` PUT/GET   |
| Highlights and notes         | `POST /v1/annotations` (liseur-sync)           |

There is no plugin-owned progress scheduler: KOReader's `kosync` plugin
already debounces pushes on page turn, suspend and close, and Coppice
implements exactly the routes it calls, so this plugin *configures* that
client instead of duplicating it. The on-demand push/pull below exists only so
a menu action can report a result.

Book identity is the one place Coppice and KOReader do not already agree, and
this plugin resolves it in three steps, most reliable first:

1. a book downloaded through this plugin records its Coppice media id in the
   document's sidecar;
2. otherwise the dashboard's `koreaderHash` is matched against the sidecar's
   `partial_md5_checksum` — the same partial MD5 Coppice stores as
   `media.koreader_hash`, so any book that has ever synced progress is
   identifiable;
3. otherwise the user links it by hand from a search.

Nothing is guessed from a title.
]]

local ConfirmBox = require("ui/widget/confirmbox")
local DataStorage = require("datastorage")
local Device = require("device")
local Dispatcher = require("dispatcher")
local InfoMessage = require("ui/widget/infomessage")
local InputDialog = require("ui/widget/inputdialog")
local LuaSettings = require("luasettings")
local NetworkMgr = require("ui/network/manager")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local md5 = require("ffi/sha2").md5
local logger = require("logger")
local _ = require("gettext")
local T = require("ffi/util").template

local Annotations = require("coppice_annotations")
local Api = require("coppice_api")
local Browser = require("coppice_browser")
local KoSync = require("coppice_kosync")
local Opds = require("coppice_opds")
local Url = require("coppice_url")
local Pairing = require("coppice_pairing")
local Migration = require("coppice_migration")

local Coppice = WidgetContainer:extend{
    name = "coppice",
    settings_file = DataStorage:getSettingsDir() .. "/coppice.lua",
    settings = nil,
    updated = nil,
}

local DEFAULT_SETTINGS = {
    server = nil,
    username = nil,
    api_key = nil,
    liseur_secret = nil,
    device_id = nil,
    device_name = nil,
    download_dir = nil,
    pairing_id = nil,
    pairing_nonce = nil,
    pairing_code = nil,
    pairing_expires_at = nil,
    pairing_poll_interval = nil,
}

local function pluginRoot()
    local source = debug.getinfo(1, "S").source or ""
    source = source:gsub("^@", "")
    local directory = source:match("^(.*)/[^/]+$")
    return directory and directory:match("^(.*)/[^/]+$")
end

local function optionalConfig()
    local ok, config = pcall(require, "coppice_config")
    return ok and type(config) == "table" and config or {}
end

function Coppice:init()
    self:loadSettings()
    if not self._actions_registered then
        self:onDispatcherRegisterActions()
        self._actions_registered = true
    end
    if not self._main_menu_registered then
        self.ui.menu:registerToMainMenu(self)
        self._main_menu_registered = true
    end
    if not self._pairing_bootstrapped then
        self._pairing_bootstrapped = true
        UIManager:scheduleIn(0.1, function() self:maybeStartPairing() end)
    end
end

function Coppice:loadSettings()
    if self.settings then return end
    Migration.run(pluginRoot(), DataStorage:getSettingsDir())
    if not Coppice.settings_obj then
        Coppice.settings_obj = LuaSettings:open(self.settings_file)
    end
    self.settings = Coppice.settings_obj:readSetting("settings", DEFAULT_SETTINGS)
    if type(self.settings) ~= "table" then self.settings = {} end
    for key, value in pairs(DEFAULT_SETTINGS) do
        if self.settings[key] == nil then self.settings[key] = value end
    end
    local config = optionalConfig()
    if not self.settings.server and type(config.server) == "string" then
        local base = Url.normalizeBase(config.server)
        if base then self.settings.server = base end
    end
    if not self.settings.download_dir and type(config.download_dir) == "string" then
        self.settings.download_dir = config.download_dir
    end
    if not self.settings.device_name and type(config.device_name) == "string" then
        self.settings.device_name = config.device_name
    end
end
function Coppice:onCoppicePair()
    self:startPairing()
    return true
end


function Coppice:saveSettings()
    Coppice.settings_obj:saveSetting("settings", self.settings)
    Coppice.settings_obj:flush()
    self.updated = nil
    self.api = nil
end

function Coppice:onFlushSettings()
    if self.updated then self:saveSettings() end
end

function Coppice:onDispatcherRegisterActions()
    Dispatcher:registerAction("coppice_browse",
        { category = "none", event = "ShowCoppiceBrowser",
          title = _("Coppice: browse library"), general = true })
    Dispatcher:registerAction("coppice_pair",
        { category = "none", event = "CoppicePair", title = _("Coppice: pair device"), general = true })
    Dispatcher:registerAction("coppice_push_progress",
        { category = "none", event = "CoppicePushProgress",
          title = _("Coppice: push reading progress"), reader = true })
    Dispatcher:registerAction("coppice_export_annotations",
        { category = "none", event = "CoppiceExportAnnotations",
          title = _("Coppice: export highlights"), reader = true })
end

-- ----------------------------------------------------------------- client

function Coppice:client()
    if self.api then return self.api end
    local base = Url.normalizeBase(self.settings.server)
    if not base then return nil end
    self.api = Api.new{
        base = base,
        username = self.settings.username or "coppice",
        api_key = self.settings.api_key,
        device_id = self.settings.device_id or G_reader_settings:readSetting("device_id"),
        device_name = self.settings.device_name or Device.model,
        liseur_secret = self.settings.liseur_secret,
    }
    return self.api
end

local function warn(message, detail)
    UIManager:show(InfoMessage:new{
        text = detail and T("%1\n%2", message, tostring(detail)) or message,
        icon = "notice-warning",
    })
end

local function inform(message)
    UIManager:show(InfoMessage:new{ text = message })
end

function Coppice:requireClient()
    local api = self:client()
    if not api then
        warn(_("Set your Coppice server address first."))
        return nil
    end
    if not api:isConfigured() then
        warn(_("Pair this device with Coppice before using the library."))
        return nil
    end
    return api
end

-- ------------------------------------------------------------------- menu

function Coppice:addToMainMenu(menu_items)
    menu_items.coppice = {
        text = _("Coppice"),
        sorting_hint = "tools",
        sub_item_table = self:menuTable(),
    }
end

function Coppice:pairingLabel()
    if (self.settings.api_key or "") ~= ""
            and (self.settings.liseur_secret or "") ~= "" then
        return _("Pairing: approved")
    end
    if self.settings.pairing_id and self.settings.pairing_nonce then
        return T(_("Pairing: waiting for approval (%1)"),
            self.settings.pairing_code or "------")
    end
    return _("Pair this device")
end

function Coppice:menuTable()
    local items = {
        {
            text = _("Browse library"),
            keep_menu_open = false,
            callback = function() self:onShowCoppiceBrowser() end,
        },
        {
            text_func = function()
                local base = Url.normalizeBase(self.settings.server)
                return base and T(_("Server: %1"), base) or _("Server: not set")
            end,
            keep_menu_open = true,
            callback = function(touchmenu_instance)
                self:showServerDialog(touchmenu_instance)
            end,
        },
        {
            text_func = function() return self:pairingLabel() end,
            keep_menu_open = true,
            callback = function(touchmenu_instance)
                self:startPairing(touchmenu_instance)
            end,
        },
        {
            text = _("Forget this device pairing"),
            keep_menu_open = true,
            callback = function(touchmenu_instance)
                self:forgetPairing(touchmenu_instance)
            end,
        },
        {
            text_func = function()
                return T(_("Download folder: %1"), self:downloadDir())
            end,
            keep_menu_open = true,
            callback = function(touchmenu_instance)
                self:chooseDownloadDir(touchmenu_instance)
            end,
            separator = true,
        },
        {
            text_func = function()
                local base = Url.normalizeBase(self.settings.server)
                if base and self.settings.api_key
                        and KoSync.isConfiguredFor(base, self.settings.api_key) then
                    return _("Automatic progress sync: configured")
                end
                return _("Set up automatic progress sync")
            end,
            help_text = _([[
Points KOReader's built-in Progress sync plugin at this Coppice server: sets the custom sync server to /koreader/<your API key>, fills in the approved username and key fields it requires, and switches document matching to Binary, which is the only method Coppice supports.

Requires an approved pairing. Restart KOReader afterwards so the built-in plugin re-reads its settings.]]),
            enabled_func = function()
                return (self.settings.api_key or "") ~= ""
                    and Url.normalizeBase(self.settings.server) ~= nil
            end,
            keep_menu_open = true,
            callback = function(touchmenu_instance)
                self:configureKosync(touchmenu_instance)
            end,
        },
        {
            text = _("Check server connection"),
            keep_menu_open = true,
            callback = function() self:checkConnection() end,
            separator = true,
        },
    }

    if self.ui.document then
        table.insert(items, {
            text = _("Push this book's progress now"),
            keep_menu_open = true,
            callback = function() self:onCoppicePushProgress() end,
        })
        table.insert(items, {
            text = _("Pull this book's progress from Coppice"),
            keep_menu_open = true,
            callback = function() self:pullProgress() end,
        })
        table.insert(items, {
            text = _("Export highlights and notes to Coppice"),
            keep_menu_open = true,
            callback = function() self:onCoppiceExportAnnotations() end,
        })
        table.insert(items, {
            text_func = function()
                local id = self:linkedBookId()
                return id and T(_("Linked book: %1"), id:sub(1, 8))
                    or _("Link this book to a Coppice book…")
            end,
            keep_menu_open = true,
            callback = function(touchmenu_instance)
                self:showLinkDialog(touchmenu_instance)
            end,
        })
    end

    return items
end

-- --------------------------------------------------------------- pairing

function Coppice:clearPairingState()
    self.settings.pairing_id = nil
    self.settings.pairing_nonce = nil
    self.settings.pairing_code = nil
    self.settings.pairing_expires_at = nil
    self.settings.pairing_poll_interval = nil
    self._pairing_poll_scheduled = nil
end

function Coppice:showPairingCode(body)
    local code = body.code or self.settings.pairing_code or "------"
    local expires = body.expires_at or self.settings.pairing_expires_at or _("unknown")
    inform(T(_([[Coppice pairing code: %1

Approve this code in Coppice before %2. Keep this screen private; the code and poll nonce are for this device only.]]), code, expires))
end

function Coppice:pairingDeviceName()
    return self.settings.device_name or Device.model or "KOReader"
end

function Coppice:maybeStartPairing()
    if (self.settings.api_key or "") ~= ""
            and (self.settings.liseur_secret or "") ~= "" then
        return
    end
    if self.settings.pairing_id and self.settings.pairing_nonce then
        self:showPairingCode({
            code = self.settings.pairing_code,
            expires_at = self.settings.pairing_expires_at,
        })
        self:schedulePairingPoll(0.2)
        return
    end
    if not Url.normalizeBase(self.settings.server) then
        self:showServerDialog(nil, true)
        return
    end
    self:startPairing()
end

function Coppice:startPairing(touchmenu_instance)
    local base = Url.normalizeBase(self.settings.server)
    if not base then
        return self:showServerDialog(touchmenu_instance, true)
    end
    if self.settings.pairing_id and self.settings.pairing_nonce then
        self:showPairingCode({
            code = self.settings.pairing_code,
            expires_at = self.settings.pairing_expires_at,
        })
        self:schedulePairingPoll(0.2)
        return
    end

    local api = self:client()
    if not api then return warn(_("Set your Coppice server address first.")) end
    NetworkMgr:runWhenConnected(function()
        local body, err, code = api:pairingStart(self:pairingDeviceName())
        if not body then
            return warn(_("Could not start Coppice pairing."), code or err)
        end
        self.settings.server = base
        self.settings.pairing_id = body.pairing_id
        self.settings.pairing_nonce = body.nonce
        self.settings.pairing_code = body.code
        self.settings.pairing_expires_at = body.expires_at
        self.settings.pairing_poll_interval = Pairing.pollInterval(body, 2)
        self:saveSettings()
        if touchmenu_instance then touchmenu_instance:updateItems() end
        self:showPairingCode(body)
        self:schedulePairingPoll(self.settings.pairing_poll_interval)
    end)
end

function Coppice:schedulePairingPoll(delay)
    if self._pairing_poll_scheduled then return end
    if not self.settings.pairing_id or not self.settings.pairing_nonce then return end
    self._pairing_poll_scheduled = true
    UIManager:scheduleIn(delay or self.settings.pairing_poll_interval or 2, function()
        self._pairing_poll_scheduled = nil
        self:pollPairing()
    end)
end

function Coppice:pollPairing()
    local pairing_id = self.settings.pairing_id
    local nonce = self.settings.pairing_nonce
    if not pairing_id or not nonce then return end
    local api = self:client()
    if not api then return end
    NetworkMgr:runWhenConnected(function()
        local body, err, code = api:pairingStatus(pairing_id, nonce)
        if not body then
            -- A transient network failure must not discard the nonce. It is
            -- safe to retry; the server still applies its five-minute expiry.
            self:schedulePairingPoll(self.settings.pairing_poll_interval or 2)
            return
        end
        if body.status == "pending" then
            self:schedulePairingPoll(Pairing.pollInterval(body,
                self.settings.pairing_poll_interval or 2))
            return
        end
        if body.status == "denied" or body.status == "expired" then
            local message = Pairing.statusMessage(body.status, body.expires_at)
            self:clearPairingState()
            self:saveSettings()
            inform(message)
            return
        end

        local credentials, credential_err = Pairing.credentials(body)
        if not credentials then
            self:clearPairingState()
            self:saveSettings()
            return warn(_("Coppice approval did not include both device credentials."), credential_err)
        end
        self.settings.username = credentials.username
        self.settings.api_key = credentials.api_key
        self.settings.liseur_secret = credentials.liseur_secret
        self.settings.device_id = credentials.device_id or self.settings.device_id
        self.settings.device_name = credentials.device_name or self.settings.device_name
        self:clearPairingState()
        self:saveSettings()
        local base = Url.normalizeBase(self.settings.server)
        local patch, patch_err = KoSync.configure(base,
            self.settings.api_key, self.settings.username)
        if patch then
            inform(_([[Coppice paired this device and configured automatic progress sync.

Restart KOReader so its Progress sync plugin reloads the settings.]]))
        else
            inform(T(_("Coppice paired this device, but automatic progress sync could not be configured: %1"),
                patch_err or _("unknown error")))
        end
    end)
end

function Coppice:forgetPairing(touchmenu_instance)
    local dialog
    dialog = ConfirmBox:new{
        text = _([[Forget this device's Coppice credentials?

This removes both local auth lanes and requires a new approval. It does not reuse old secrets.]]),
        ok_text = _("Forget"),
        ok_callback = function()
            self.settings.username = nil
            self.settings.api_key = nil
            self.settings.liseur_secret = nil
            self.settings.device_id = nil
            self:clearPairingState()
            self:saveSettings()
            if touchmenu_instance then touchmenu_instance:updateItems() end
            inform(_("Local Coppice credentials removed. Start pairing again when ready."))
        end,
    }
    UIManager:show(dialog)
end

--- Called by an installer/uninstaller integration before removing the folder.
--- It never exports or migrates credentials.
function Coppice:onUninstall()
    self.settings.username = nil
    self.settings.api_key = nil
    self.settings.liseur_secret = nil
    self.settings.device_id = nil
    self:clearPairingState()
    self:saveSettings()
    pcall(os.remove, self.settings_file)
end

-- --------------------------------------------------------------- settings

function Coppice:downloadDir()
    if (self.settings.download_dir or "") ~= "" then
        return self.settings.download_dir
    end
    return G_reader_settings:readSetting("download_dir")
        or G_reader_settings:readSetting("lastdir")
        or DataStorage:getFullDataDir()
end

function Coppice:showServerDialog(touchmenu_instance, auto_pair)
    local dialog
    dialog = InputDialog:new{
        title = _("Coppice server address"),
        input = self.settings.server or "http://",
        input_hint = "http://192.168.1.10:10801",
        description = _([[
The server root, for example http://192.168.1.10:10801. A pasted OPDS, /api/v2 or /koreader/<key> URL is trimmed back to the root automatically. After saving, Coppice starts a five-minute device pairing window.]]),
        buttons = {{
            { text = _("Cancel"), id = "close", callback = function()
                UIManager:close(dialog)
            end },
            { text = _("Save and pair"), is_enter_default = true, callback = function()
                local value = dialog:getInputText()
                local base = Url.normalizeBase(value)
                if not base then
                    return warn(_("That is not an http:// or https:// address."))
                end
                UIManager:close(dialog)
                if self.settings.server ~= base then
                    self.settings.username = nil
                    self.settings.api_key = nil
                    self.settings.liseur_secret = nil
                    self.settings.device_id = nil
                    self:clearPairingState()
                end
                self.settings.server = base
                self:saveSettings()
                if touchmenu_instance then touchmenu_instance:updateItems() end
                self:startPairing(touchmenu_instance)
            end },
        }},
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

function Coppice:chooseDownloadDir(touchmenu_instance)
    local PathChooser = require("ui/widget/pathchooser")
    UIManager:show(PathChooser:new{
        select_directory = true,
        select_file = false,
        path = self:downloadDir(),
        onConfirm = function(path)
            self.settings.download_dir = path
            self:saveSettings()
            if touchmenu_instance then touchmenu_instance:updateItems() end
        end,
    })
end

-- ------------------------------------------------------------------ actions

function Coppice:onShowCoppiceBrowser()
    local api = self:requireClient()
    if not api then return true end

    self.browser = Browser:new{
        api = api,
        download_dir = self:downloadDir(),
        title = _("Coppice"),
        title_bar_fm_style = true,
        on_download_complete = function(path, book)
            self:rememberDownload(path, book)
            self:openDownloadedFile(path)
        end,
        close_callback = function()
            UIManager:close(self.browser)
            self.browser = nil
        end,
    }
    UIManager:show(self.browser)
    return true
end

--- Closes the browser and opens the file.
---
--- Which call opens it depends on where the browser was opened from: from the
--- reader the document has to be *switched*, from the file browser it is
--- simply opened. Getting this wrong leaves two documents live.
function Coppice:openDownloadedFile(file)
    if self.browser then self.browser.close_callback() end
    if self.ui.document then
        self.ui:switchDocument(file)
    else
        self.ui:openFile(file)
    end
end

function Coppice:checkConnection()
    local api = self:requireClient()
    if not api then return end
    NetworkMgr:runWhenConnected(function()
        local lines = {}

        local catalog, err, code = api:opdsCatalog()
        table.insert(lines, catalog and _("OPDS 2.0: OK")
            or T(_("OPDS 2.0: %1"), tostring(code or err)))

        local items, api_err, api_code = api:continueReading(1)
        if items then
            table.insert(lines, T(_("Reading list: OK (%1 in progress)"), #items))
        else
            table.insert(lines, T(_("Reading list: %1"), tostring(api_code or api_err)))
        end

        if (self.settings.api_key or "") ~= "" then
            local auth, ko_err, ko_code = api:kosyncAuth()
            table.insert(lines, auth and _("Progress sync: OK")
                or T(_("Progress sync: %1"), tostring(ko_code or ko_err)))
        else
            table.insert(lines, _("Progress sync: no API key set"))
        end

        if (self.settings.liseur_secret or "") ~= "" then
            local token, token_err = api:liseurDescribeToken(self.settings.liseur_secret)
            table.insert(lines, token and _("Annotation lane: OK")
                or T(_("Annotation lane: %1"), tostring(token_err or "rejected")))
        else
            table.insert(lines, _("Annotation lane: no paired device token"))
        end

        inform(table.concat(lines, "\n"))
    end)
end

function Coppice:configureKosync(touchmenu_instance)
    local base = Url.normalizeBase(self.settings.server)
    if not base or (self.settings.api_key or "") == "" then
        return warn(_("A server address and an API key are required."))
    end
    NetworkMgr:runWhenConnected(function()
        local api = self:requireClient()
        if not api then return end
        local ok, err, code = api:kosyncAuth()
        if not ok then
            return warn(_("Coppice rejected that API key for progress sync."),
                code or err)
        end
        local patch, patch_err =
            KoSync.configure(base, self.settings.api_key, self.settings.username)
        if not patch then
            return warn(_("Could not write the progress sync settings."), patch_err)
        end
        if touchmenu_instance then touchmenu_instance:updateItems() end
        inform(T(_([[
Progress sync now points at:

%1

Document matching is set to Binary. Restart KOReader so its Progress sync plugin picks this up.]]), patch.custom_server))
    end)
end

-- ------------------------------------------------------- book <-> media id

--- The Coppice media id for the open document, if known.
function Coppice:linkedBookId()
    if not self.ui or not self.ui.doc_settings then return nil end
    local id = self.ui.doc_settings:readSetting("coppice_media_id")
    if type(id) ~= "string" or id == "" then return nil end
    return id
end

function Coppice:setLinkedBookId(id)
    if not self.ui or not self.ui.doc_settings then return end
    self.ui.doc_settings:saveSetting("coppice_media_id", id)
    self.ui.doc_settings:flush()
end

--- Records the media id on a freshly downloaded file's sidecar.
---
--- The sidecar is written before the book is opened, so the link exists the
--- first time the reader asks for it.
function Coppice:rememberDownload(path, book)
    if not book or not book.id then return end
    local DocSettings = require("docsettings")
    local doc_settings = DocSettings:open(path)
    doc_settings:saveSetting("coppice_media_id", book.id)
    doc_settings:flush()
    logger.dbg("Coppice: linked", path, "to media", book.id)
end

--- Resolves the open document to a Coppice media id.
---
--- Step 2 of the identity ladder: the dashboard hands back
--- `media.koreader_hash` for every book in progress, and the sidecar holds the
--- same partial MD5, so an exact string match identifies the book with no
--- guessing. Only books with a reading head are covered, which is exactly the
--- set that has ever synced progress.
function Coppice:resolveBookIdByHash(api)
    local hash = KoSync.documentHash(self.ui and self.ui.doc_settings)
    if not hash then return nil, "no_partial_md5" end
    local items, err, code = api:continueReading(50)
    if not items then return nil, code or err end
    for _, item in ipairs(items) do
        if type(item) == "table"
                and item.koreaderHash == hash
                and type(item.mediaId) == "string"
                and item.mediaId ~= "" then
            self:setLinkedBookId(item.mediaId)
            return item.mediaId
        end
    end
    return nil, "not_in_reading_list"
end

function Coppice:bookId(api)
    return self:linkedBookId() or self:resolveBookIdByHash(api)
end

function Coppice:showLinkDialog(touchmenu_instance)
    local api = self:requireClient()
    if not api then return end
    local dialog
    local title = self.ui and self.ui.doc_props and self.ui.doc_props.display_title
    dialog = InputDialog:new{
        title = _("Find this book on Coppice"),
        input = title or "",
        input_hint = _("title or author"),
        description = _([[
Searches your Coppice library and links the open document to the book you pick, so progress and highlights land on the right record.]]),
        buttons = {{
            { text = _("Cancel"), id = "close", callback = function()
                UIManager:close(dialog)
            end },
            { text = _("Search"), is_enter_default = true, callback = function()
                local query = dialog:getInputText()
                UIManager:close(dialog)
                if not query or query == "" then return end
                NetworkMgr:runWhenConnected(function()
                    self:pickSearchResult(api, query, touchmenu_instance)
                end)
            end },
        }},
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

function Coppice:pickSearchResult(api, query, touchmenu_instance)
    local feed, err, code = api:opdsSearch(query, 1, 20)
    if not feed then
        return warn(_("Search failed."), code or err)
    end
    local candidates = {}
    for _, group in ipairs(Opds.groups(api.base, feed)) do
        for _, pub in ipairs(group.publications) do
            if pub.id then table.insert(candidates, pub) end
        end
    end
    for _, pub in ipairs(Opds.publications(api.base, feed)) do
        if pub.id then table.insert(candidates, pub) end
    end
    if #candidates == 0 then
        return warn(_("No matching books on the server."))
    end

    local Menu = require("ui/widget/menu")
    local rows, picker = {}, nil
    for _, pub in ipairs(candidates) do
        local label = pub.title
        if pub.series and pub.series ~= pub.title then
            label = pub.series .. " — " .. label
        end
        table.insert(rows, {
            text = label,
            callback = function()
                UIManager:close(picker)
                self:setLinkedBookId(pub.id)
                if touchmenu_instance then touchmenu_instance:updateItems() end
                inform(T(_("Linked to %1."), pub.title))
            end,
        })
    end
    picker = Menu:new{
        title = _("Pick the matching book"),
        item_table = rows,
        is_popout = false,
        is_borderless = true,
        onMenuSelect = function(_menu, item)
            item.callback()
            return true
        end,
        close_callback = function() UIManager:close(picker) end,
    }
    UIManager:show(picker)
end

-- --------------------------------------------------------------- progress

--- The progress string and percentage KOReader would push itself.
---
--- A paged document reports a page number, a reflowable one a crengine DOM
--- x-pointer. Coppice stores a numeric value as a page and keeps a non-numeric
--- one verbatim as `koreader_progress`; it never converts between them.
function Coppice:currentProgress()
    local document = self.ui and self.ui.document
    local Math = require("optmath")
    if not document or not document.info then return nil end
    local reader = document.info.has_pages and self.ui.paging or self.ui.rolling
    if not reader then return nil end
    local progress = reader:getLastProgress()
    local percentage = reader:getLastPercent()
    if type(percentage) ~= "number" or percentage ~= percentage then
        return progress, nil
    end
    return progress, Math.roundPercent(percentage)
end

function Coppice:onCoppicePushProgress()
    local api = self:requireClient()
    if not api then return true end
    if (self.settings.api_key or "") == "" then
        warn(_("Progress sync needs an API key."))
        return true
    end
    local hash = KoSync.documentHash(self.ui and self.ui.doc_settings)
    if not hash then
        warn(_("This book has no partial MD5 yet — open it once and try again."))
        return true
    end
    local progress, percentage = self:currentProgress()
    if progress == nil then
        warn(_("No reading position to push."))
        return true
    end
    NetworkMgr:runWhenConnected(function()
        local body, err, code = api:kosyncPush(hash, progress, percentage)
        if not body then
            if code == 404 then
                return warn(_([[
Coppice does not know this file.

Its partial MD5 is not in your library: either the book was not scanned with hashing enabled, or this file is not the copy Coppice has.]]))
            end
            return warn(_("Push failed."), code or err)
        end
        inform(T(_("Pushed %1%% to Coppice."),
            math.floor((percentage or 0) * 100 + 0.5)))
    end)
    return true
end

function Coppice:pullProgress()
    local api = self:requireClient()
    if not api then return end
    if (self.settings.api_key or "") == "" then
        return warn(_("Progress sync needs an API key."))
    end
    local hash = KoSync.documentHash(self.ui and self.ui.doc_settings)
    if not hash then
        return warn(_("This book has no partial MD5 yet."))
    end
    NetworkMgr:runWhenConnected(function()
        local body, err, code = api:kosyncPull(hash)
        if not body then return warn(_("Pull failed."), code or err) end
        if not body.progress then
            return inform(_("Coppice has no saved position for this book."))
        end
        local percentage = tonumber(body.percentage) or 0
        if percentage < 0 or percentage > 1 then
            return warn(_("Coppice returned an invalid progress response."))
        end
        local document = self.ui and self.ui.document
        local has_pages = document and document.info and document.info.has_pages
        local target_page = has_pages and tonumber(body.progress) or nil
        if has_pages and not target_page then
            return warn(_("Coppice returned an invalid page position."))
        end
        UIManager:show(ConfirmBox:new{
            text = T(_("Coppice has this book at %1%% (from %2).\n\nJump there?"),
                math.floor(percentage * 100 + 0.5),
                body.device or _("another device")),
            ok_text = _("Jump"),
            ok_callback = function()
                local Event = require("ui/event")
                if has_pages then
                    self.ui:handleEvent(Event:new("GotoPage", target_page))
                else
                    self.ui:handleEvent(Event:new("GotoXPointer", body.progress))
                end
            end,
        })
    end)
end

-- ------------------------------------------------------------ annotations

--- Where the plugin remembers each annotation's last accepted server
--- revision, so the next push is a compare-and-set edit instead of a
--- create-that-conflicts.
function Coppice:annotationRevisions()
    if not self.ui or not self.ui.doc_settings then return {} end
    return self.ui.doc_settings:readSetting("coppice_annotation_revs") or {}
end

function Coppice:saveAnnotationRevisions(revisions)
    if not self.ui or not self.ui.doc_settings then return end
    self.ui.doc_settings:saveSetting("coppice_annotation_revs", revisions)
    self.ui.doc_settings:flush()
end

function Coppice:onCoppiceExportAnnotations()
    local api = self:requireClient()
    if not api then return true end
    local items = self.ui and self.ui.annotation and self.ui.annotation.annotations
    if not items or #items == 0 then
        warn(_("This book has no highlights, notes or bookmarks."))
        return true
    end

    NetworkMgr:runWhenConnected(function()
        self:exportAnnotations(api, items)
    end)
    return true
end

function Coppice:exportAnnotations(api, items)
    local secret = self.settings.liseur_secret
    if type(secret) ~= "string" or secret == "" then
        return warn(_("Pair this device before exporting annotations."))
    end

    local book_id, id_err = self:bookId(api)
    if not book_id then
        return warn(_([[
This book is not linked to a Coppice book yet.

Use "Link this book to a Coppice book…", or push its progress once so Coppice can match it by hash.]]), id_err)
    end

    local work_id, resolved = api:liseurResolveWork(secret, book_id)
    if not work_id then
        return warn(_("Coppice could not resolve this book's work id."), resolved)
    end

    -- When the server matched an exact-bytes edition it hands the digest back
    -- in `identifiers`; pinning the annotation to it is strictly better
    -- provenance than the work alone. It is often absent (a library whose
    -- files Coppice could not read in full), and inventing one would be worse
    -- than omitting it.
    local edition_sha
    for _, identifier in ipairs(resolved and resolved.identifiers or {}) do
        if identifier.kind == "sha256" and type(identifier.value) == "string" then
            edition_sha = identifier.value
        end
    end

    local revisions = self:annotationRevisions()
    local inputs, skipped = Annotations.batch(items, {
        work_id = work_id,
        edition_sha = edition_sha,
        document_hash = KoSync.documentHash(self.ui.doc_settings),
        page_count = self.ui.document and self.ui.document:getPageCount() or nil,
        digest = md5,
        revisions = revisions,
    })

    if #inputs == 0 then
        return warn(_("Nothing exportable in this book's annotations."))
    end

    local applied, duplicate, conflict, invalid = 0, 0, 0, 0
    for _, chunk in ipairs(Annotations.chunk(inputs)) do
        local body, push_err, code = api:liseurPushAnnotations(secret, chunk)
        if not body then
            return warn(_("Push failed after %1 annotations."), code or push_err)
        end
        for _, result in ipairs(body.results or {}) do
            if result.status == "applied" then
                applied = applied + 1
                if result.id and result.rev then
                    revisions[result.id] = result.rev
                end
            elseif result.status == "duplicate" then
                duplicate = duplicate + 1
                if result.id and result.rev then
                    revisions[result.id] = result.rev
                end
            elseif result.status == "conflict" then
                conflict = conflict + 1
                -- `server` is the server's current copy (`AnnotationResult.
                -- server`); recording its revision makes the next push a
                -- compare-and-set edit instead of the same stale create.
                if result.id and result.server and result.server.rev then
                    revisions[result.id] = result.server.rev
                end
            else
                invalid = invalid + 1
                logger.warn("Coppice: annotation rejected", result.id,
                    result.reason or result.status)
            end
        end
    end
    self:saveAnnotationRevisions(revisions)

    local lines = { T(_("Sent %1 annotations to Coppice."), #inputs) }
    table.insert(lines, T(_("applied %1 · already there %2 · conflict %3 · rejected %4"),
        applied, duplicate, conflict, invalid))
    for reason, count in pairs(skipped) do
        table.insert(lines, T(_("skipped %1: %2"), count, reason))
    end

    -- Read the live set back: the per-item statuses say what the batch did,
    -- this says what the server now holds, which is the thing the user
    -- actually wanted to know.
    local live = api:liseurWorkAnnotations(secret, work_id)
    if live and live.annotations then
        table.insert(lines,
            T(_("Coppice now holds %1 for this book."), #live.annotations))
    end

    inform(table.concat(lines, "\n"))
end

return Coppice
