local _ = require("gettext")
return {
    name = "coppice",
    fullname = _("Coppice"),
    description = _([[Browse, download and sync with a self-hosted Coppice server.

Continue-reading dashboard from Coppice's unified reading state, catalogue browsing and search over OPDS 2.0, book downloads into a folder you choose, reading-progress push and pull over Coppice's KOSync endpoints (including one-tap setup of KOReader's built-in Progress sync plugin), and export of highlights, notes and bookmarks to Coppice's liseur-sync annotation lane.]]),
}
